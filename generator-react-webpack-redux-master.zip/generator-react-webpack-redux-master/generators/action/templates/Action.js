module.exports = function(parameter) {
  return { type: '<%= actionConstant %>', parameter };
};
